module Wp2txt
  VERSION = "0.9.1"
end
